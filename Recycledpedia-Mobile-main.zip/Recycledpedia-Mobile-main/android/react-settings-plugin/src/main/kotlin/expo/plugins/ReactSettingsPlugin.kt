package expo.plugins

import org.gradle.api.Plugin
import org.gradle.api.initialization.Settings

class ReactSettingsPlugin : Plugin<Settings> {
  override fun apply(settings: Settings) {
    // Do nothing, just register the plugin.
  }
}
